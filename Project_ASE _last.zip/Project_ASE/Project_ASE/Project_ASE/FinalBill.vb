﻿Public Class FinalBill
    Private TicketSet As DataSet
    '  Public Sub New(_TicketSet As DataSet)

    ' InitializeComponent()
    '  TicketSet = _TicketSet
    ' Add any initialization after the InitializeComponent() call.

    ' End Sub

    '  Public Property Table1 As Object
    Private Sub FinalBill_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        '  lblTokenNoFB.Text = TicketSet.Tables(0).Rows(0)("TicketHeaderID")

        '  lblFName2rFB.Text = TicketSet.Tables(0).Rows(0)("TicketHeaderCustFName")
        '  lblLName2rFB.Text = TicketSet.Tables(0).Rows(0)("TicketHeaderCustLName")

        ' lblLPlaneNo2rFB.Text = TicketSet.Tables(0).Rows(0)("TicketHeaderCustCarPlateNumber")
        ' lblDLNo2rFB.Text = TicketSet.Tables(0).Rows(0)("TicketHeaderCustDLNumber")
        ' lblContactNo2rFB.Text = TicketSet.Tables(0).Rows(0)("TicketHeaderCustPhoneNumber")
        'lblServicesSelectedFB.Text = TicketSet.Tables(0).Rows(0)("TicketHeaderServicesSelected")
        ' lblInTime2rFB.Text = TicketSet.Tables(0).Rows(0)("TicketHeaderTimeIn")
        'lblOutTime2rFB.Text = TimeOfDay
        'lblTotalTimeFB.Text = TimeOfDay
        ' If TicketSet.Tables(0).Rows(0)("@TicketHeaderServicesSelected") = "OilChange, CollantServ, TireServ, CarWash" Then
        ' lblServiceChargesFB2.Text = "$240"
        ' ElseIf TicketSet.Tables(0).Rows(0)("@TicketHeaderServicesSelected") = "OilChange, CollantServ, TireServ" Then
        'lblServiceChargesFB2.Text = "$210"
        'ElseIf (CheckBox1.Checked And CheckBox2.Checked) = True Then
        '   params(6).Value = "OilChange, CollantServ"
        'ElseIf (CheckBox1.Checked And CheckBox3.Checked) = True Then
        '   params(6).Value = "OilChange, TireServ"
        'ElseIf (CheckBox2.Checked And CheckBox3.Checked And CheckBox4.Checked) = True Then
        '   params(6).Value = "CollantServ, TireServ, CarWash"
        'ElseIf (CheckBox2.Checked And CheckBox3.Checked) = True Then
        '   params(6).Value = "CollantServ, TireServ"
        'ElseIf (CheckBox2.Checked And CheckBox4.Checked) = True Then
        '   params(6).Value = "CollantServ, CarWash"
        'ElseIf (CheckBox3.Checked And CheckBox4.Checked) = True Then
        '   params(6).Value = "TireServ, CarWash"
        'ElseIf (CheckBox1.Checked) = True Then
        '   params(6).Value = "OilChange"
        'ElseIf (CheckBox2.Checked) = True Then
        '   params(6).Value = "CoolantServ"
        'ElseIf (CheckBox3.Checked) = True Then
        '  params(6).Value = "TireServ"
        'ElseIf (CheckBox4.Checked) = True Then
        '   params(6).Value = "CarWash"
        'Else
        '   params(6).Value = "No Additional Services Selected"

        'End If
        ' lblServiceChargesFB2 = 
    End Sub

    Private Sub lblTokenFB_Click(sender As Object, e As EventArgs) Handles lblTokenFB.Click

    End Sub

    Private Sub Label1_Click(sender As Object, e As EventArgs) Handles Label1.Click

    End Sub

    Private Sub lblFName2rFB_Click(sender As Object, e As EventArgs) Handles lblFName2rFB.Click

    End Sub

    Private Sub lblTokenNoFB_Click(sender As Object, e As EventArgs) Handles lblTokenNoFB.Click

    End Sub

    Private Sub lblDLNo2rFB_Click(sender As Object, e As EventArgs) Handles lblDLNo2rFB.Click

    End Sub

    Private Sub lblTotalTimeFB_Click(sender As Object, e As EventArgs) Handles lblTotalTimeFB.Click

    End Sub
End Class