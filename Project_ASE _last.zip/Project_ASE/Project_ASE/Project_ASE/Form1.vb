﻿Imports System.Data.SqlClient
Imports System.Data.ConnectionState


Public Class Register
    Private DBCon As New SqlConnection("Server=DESKTOP-CVQ6DL9;Database=ParkingService;Trusted_Connection=True;")
    Private DBCmd As SqlCommand
    Private overload As Integer

    Private Sub btnClear_Click(sender As Object, e As EventArgs) Handles btnClear.Click
        txtFName.Text = ""
        txtLName.Text = ""
        txtLPlateNo.Text = ""
        txtDLNo.Text = ""
        txtContactNo.Text = ""
        CheckBox1.Checked = False
        CheckBox2.Checked = False
        CheckBox3.Checked = False
        CheckBox4.Checked = False
    End Sub

    Private Sub btnRegister_Click(sender As Object, e As EventArgs) Handles btnRegister.Click
        If txtFName.Text = "" Or txtLName.Text = "" Or txtLPlateNo.Text = "" Or txtDLNo.Text = "" Or txtContactNo.Text = "" Then
            MsgBox("Please enter all the information", MsgBoxStyle.OkOnly, "Invalid")
        Else
            login.Show()
            Counter = Counter + 1
            If CheckBox1.Checked = True Then
                str &= CheckBox1.Text
                str &= ", "
                ServiceCharges = ServiceCharges + OilPrice
            End If
            If CheckBox2.Checked = True Then
                str &= CheckBox2.Text
                str &= ", "
                ServiceCharges = ServiceCharges + CoolantPrice
            End If
            If CheckBox3.Checked = True Then
                str &= CheckBox3.Text
                str &= ", "
                ServiceCharges = ServiceCharges + TirePrice
            End If
            If CheckBox4.Checked = True Then
                str &= CheckBox4.Text
                str &= ", "
                ServiceCharges = ServiceCharges + WashPrice
            End If
        End If

        Dim params(8) As SqlParameter
        params(0) = New SqlParameter("@TicketHeaderID", SqlDbType.Int)
        params(0).Value = txtDLNo.Text * 23

        params(1) = New SqlParameter("@TicketHeaderCustFName", SqlDbType.NVarChar)
        params(1).Value = txtFName.Text

        params(2) = New SqlParameter("@TicketHeaderCustLName", SqlDbType.NVarChar)
        params(2).Value = txtLName.Text

        params(3) = New SqlParameter("@TicketHeaderCustCarPlateNumber", SqlDbType.NVarChar)
        params(3).Value = txtLPlateNo.Text

        params(4) = New SqlParameter("@TicketHeaderCustDLNumber", SqlDbType.NVarChar)
        params(4).Value = txtDLNo.Text

        params(5) = New SqlParameter("@TicketHeaderCustPhoneNumber", SqlDbType.NVarChar)
        params(5).Value = txtContactNo.Text


        params(6) = New SqlParameter("@TicketHeaderServicesSelected", SqlDbType.NVarChar)

        If (CheckBox1.Checked And CheckBox2.Checked And CheckBox3.Checked And CheckBox4.Checked) = True Then
            params(6).Value = "OilChange, CollantServ, TireServ, CarWash"
        ElseIf (CheckBox1.Checked And CheckBox2.Checked And CheckBox3.Checked) = True Then
            params(6).Value = "OilChange, CollantServ, TireServ"
        ElseIf (CheckBox1.Checked And CheckBox2.Checked) = True Then
            params(6).Value = "OilChange, CollantServ"
        ElseIf (CheckBox1.Checked And CheckBox3.Checked) = True Then
            params(6).Value = "OilChange, TireServ"
        ElseIf (CheckBox2.Checked And CheckBox3.Checked And CheckBox4.Checked) = True Then
            params(6).Value = "CollantServ, TireServ, CarWash"
        ElseIf (CheckBox2.Checked And CheckBox3.Checked) = True Then
            params(6).Value = "CollantServ, TireServ"
        ElseIf (CheckBox2.Checked And CheckBox4.Checked) = True Then
            params(6).Value = "CollantServ, CarWash"
        ElseIf (CheckBox3.Checked And CheckBox4.Checked) = True Then
            params(6).Value = "TireServ, CarWash"
        ElseIf (CheckBox1.Checked) = True Then
            params(6).Value = "OilChange"
        ElseIf (CheckBox2.Checked) = True Then
            params(6).Value = "CoolantServ"
        ElseIf (CheckBox3.Checked) = True Then
            params(6).Value = "TireServ"
        ElseIf (CheckBox4.Checked) = True Then
            params(6).Value = "CarWash"
        Else
            params(6).Value = "No Additional Services Selected"

        End If

        params(7) = New SqlParameter("@TicketHeaderTimeIn", SqlDbType.NVarChar)
        params(7).Value = TimeOfDay

        params(8) = New SqlParameter("@IDBack", SqlDbType.Int)
        params(8).Value = ParameterDirection.Output

        Dim command As New SqlCommand()
        command.Connection = DBCon
        command.CommandType = CommandType.StoredProcedure
        command.CommandText = "sp_TicketHeaderSet3"

        command.Parameters.AddRange(params)

        DBCon.Open()

        command.ExecuteNonQuery()

        DBCon.Close()



    End Sub

    Private Sub btnPickCar_Click(sender As Object, e As EventArgs) Handles btnPickCar.Click
        login.Show()
        login.txtPassword.Text = ""
        login.txtUsername.Text = ""
    End Sub

    Private Sub Register_Load(sender As Object, e As EventArgs) Handles MyBase.Activated

    End Sub

    Private Sub Register_Load_1(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub
End Class
