﻿Module Module1
    Friend Counter As Int32 = 0
    Friend str As String = " "

    Friend Const OilPrice As Int32 = 50
    Friend Const CoolantPrice As Int32 = 60
    Friend Const TirePrice As Int32 = 100
    Friend Const WashPrice As Int32 = 30
    Friend Const ParkingPerHour As Double = 0.15

    Friend ParkingCharges As Double
    Friend ServiceCharges As Double
    Friend TotalCharges As Double

    Friend InTime As DateTime
    Friend OutTime As DateTime
    Friend TotalTime As TimeSpan
    Friend TotalHours As Double

End Module
