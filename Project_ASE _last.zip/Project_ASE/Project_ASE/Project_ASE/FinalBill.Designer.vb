﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class FinalBill
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.lblTotalTimeFB = New System.Windows.Forms.Label()
        Me.lblTotalTFB = New System.Windows.Forms.Label()
        Me.lblOutTime2rFB = New System.Windows.Forms.Label()
        Me.lblOutTimeFB = New System.Windows.Forms.Label()
        Me.lblServicesSelectedFB = New System.Windows.Forms.Label()
        Me.lblInTime2rFB = New System.Windows.Forms.Label()
        Me.lblInTimeFB = New System.Windows.Forms.Label()
        Me.lblService2FB = New System.Windows.Forms.Label()
        Me.lblContactNo2rFB = New System.Windows.Forms.Label()
        Me.lblDLNo2rFB = New System.Windows.Forms.Label()
        Me.lblLPlaneNo2rFB = New System.Windows.Forms.Label()
        Me.lblFName2rFB = New System.Windows.Forms.Label()
        Me.lblContactNo2FB = New System.Windows.Forms.Label()
        Me.lblDLNo2FB = New System.Windows.Forms.Label()
        Me.lblLPlateNo2FB = New System.Windows.Forms.Label()
        Me.lblName2FB = New System.Windows.Forms.Label()
        Me.lblTokenNoFB = New System.Windows.Forms.Label()
        Me.lblTokenFB = New System.Windows.Forms.Label()
        Me.lblTotalChargesFB = New System.Windows.Forms.Label()
        Me.lblTotalChargesFB2 = New System.Windows.Forms.Label()
        Me.lblFinalBillHeader = New System.Windows.Forms.Label()
        Me.lblFinalBillFooter = New System.Windows.Forms.Label()
        Me.lblServiceChargesFB2 = New System.Windows.Forms.Label()
        Me.lblServiceChargesFB = New System.Windows.Forms.Label()
        Me.lblParkigChargesFB2 = New System.Windows.Forms.Label()
        Me.lblParkingChargesFB = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.lblLName2rFB = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'lblTotalTimeFB
        '
        Me.lblTotalTimeFB.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblTotalTimeFB.Location = New System.Drawing.Point(243, 353)
        Me.lblTotalTimeFB.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblTotalTimeFB.Name = "lblTotalTimeFB"
        Me.lblTotalTimeFB.Size = New System.Drawing.Size(268, 31)
        Me.lblTotalTimeFB.TabIndex = 43
        Me.lblTotalTimeFB.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'lblTotalTFB
        '
        Me.lblTotalTFB.AutoSize = True
        Me.lblTotalTFB.Font = New System.Drawing.Font("Palatino Linotype", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblTotalTFB.Location = New System.Drawing.Point(86, 369)
        Me.lblTotalTFB.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblTotalTFB.Name = "lblTotalTFB"
        Me.lblTotalTFB.Size = New System.Drawing.Size(90, 22)
        Me.lblTotalTFB.TabIndex = 42
        Me.lblTotalTFB.Text = "Total Time: "
        '
        'lblOutTime2rFB
        '
        Me.lblOutTime2rFB.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblOutTime2rFB.Location = New System.Drawing.Point(203, 333)
        Me.lblOutTime2rFB.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblOutTime2rFB.Name = "lblOutTime2rFB"
        Me.lblOutTime2rFB.Size = New System.Drawing.Size(126, 31)
        Me.lblOutTime2rFB.TabIndex = 41
        Me.lblOutTime2rFB.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'lblOutTimeFB
        '
        Me.lblOutTimeFB.AutoSize = True
        Me.lblOutTimeFB.Font = New System.Drawing.Font("Palatino Linotype", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblOutTimeFB.Location = New System.Drawing.Point(86, 336)
        Me.lblOutTimeFB.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblOutTimeFB.Name = "lblOutTimeFB"
        Me.lblOutTimeFB.Size = New System.Drawing.Size(83, 22)
        Me.lblOutTimeFB.TabIndex = 40
        Me.lblOutTimeFB.Text = "Out Time: "
        '
        'lblServicesSelectedFB
        '
        Me.lblServicesSelectedFB.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblServicesSelectedFB.Location = New System.Drawing.Point(243, 260)
        Me.lblServicesSelectedFB.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblServicesSelectedFB.Name = "lblServicesSelectedFB"
        Me.lblServicesSelectedFB.Size = New System.Drawing.Size(355, 28)
        Me.lblServicesSelectedFB.TabIndex = 39
        Me.lblServicesSelectedFB.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'lblInTime2rFB
        '
        Me.lblInTime2rFB.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblInTime2rFB.Location = New System.Drawing.Point(221, 300)
        Me.lblInTime2rFB.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblInTime2rFB.Name = "lblInTime2rFB"
        Me.lblInTime2rFB.Size = New System.Drawing.Size(125, 31)
        Me.lblInTime2rFB.TabIndex = 38
        Me.lblInTime2rFB.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'lblInTimeFB
        '
        Me.lblInTimeFB.AutoSize = True
        Me.lblInTimeFB.Font = New System.Drawing.Font("Palatino Linotype", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblInTimeFB.Location = New System.Drawing.Point(86, 303)
        Me.lblInTimeFB.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblInTimeFB.Name = "lblInTimeFB"
        Me.lblInTimeFB.Size = New System.Drawing.Size(70, 22)
        Me.lblInTimeFB.TabIndex = 37
        Me.lblInTimeFB.Text = "In Time: "
        '
        'lblService2FB
        '
        Me.lblService2FB.AutoSize = True
        Me.lblService2FB.Font = New System.Drawing.Font("Palatino Linotype", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblService2FB.Location = New System.Drawing.Point(86, 270)
        Me.lblService2FB.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblService2FB.Name = "lblService2FB"
        Me.lblService2FB.Size = New System.Drawing.Size(125, 22)
        Me.lblService2FB.TabIndex = 36
        Me.lblService2FB.Text = "Selected Service.:"
        '
        'lblContactNo2rFB
        '
        Me.lblContactNo2rFB.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblContactNo2rFB.Location = New System.Drawing.Point(243, 228)
        Me.lblContactNo2rFB.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblContactNo2rFB.Name = "lblContactNo2rFB"
        Me.lblContactNo2rFB.Size = New System.Drawing.Size(218, 31)
        Me.lblContactNo2rFB.TabIndex = 35
        Me.lblContactNo2rFB.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'lblDLNo2rFB
        '
        Me.lblDLNo2rFB.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblDLNo2rFB.Location = New System.Drawing.Point(243, 196)
        Me.lblDLNo2rFB.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblDLNo2rFB.Name = "lblDLNo2rFB"
        Me.lblDLNo2rFB.Size = New System.Drawing.Size(218, 31)
        Me.lblDLNo2rFB.TabIndex = 34
        Me.lblDLNo2rFB.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'lblLPlaneNo2rFB
        '
        Me.lblLPlaneNo2rFB.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblLPlaneNo2rFB.Location = New System.Drawing.Point(243, 164)
        Me.lblLPlaneNo2rFB.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblLPlaneNo2rFB.Name = "lblLPlaneNo2rFB"
        Me.lblLPlaneNo2rFB.Size = New System.Drawing.Size(218, 31)
        Me.lblLPlaneNo2rFB.TabIndex = 33
        Me.lblLPlaneNo2rFB.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'lblFName2rFB
        '
        Me.lblFName2rFB.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblFName2rFB.Location = New System.Drawing.Point(243, 100)
        Me.lblFName2rFB.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblFName2rFB.Name = "lblFName2rFB"
        Me.lblFName2rFB.Size = New System.Drawing.Size(185, 31)
        Me.lblFName2rFB.TabIndex = 31
        Me.lblFName2rFB.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'lblContactNo2FB
        '
        Me.lblContactNo2FB.AutoSize = True
        Me.lblContactNo2FB.Font = New System.Drawing.Font("Palatino Linotype", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblContactNo2FB.Location = New System.Drawing.Point(86, 237)
        Me.lblContactNo2FB.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblContactNo2FB.Name = "lblContactNo2FB"
        Me.lblContactNo2FB.Size = New System.Drawing.Size(96, 22)
        Me.lblContactNo2FB.TabIndex = 30
        Me.lblContactNo2FB.Text = "Contact No.:"
        '
        'lblDLNo2FB
        '
        Me.lblDLNo2FB.AutoSize = True
        Me.lblDLNo2FB.Font = New System.Drawing.Font("Palatino Linotype", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblDLNo2FB.Location = New System.Drawing.Point(86, 205)
        Me.lblDLNo2FB.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblDLNo2FB.Name = "lblDLNo2FB"
        Me.lblDLNo2FB.Size = New System.Drawing.Size(151, 22)
        Me.lblDLNo2FB.TabIndex = 29
        Me.lblDLNo2FB.Text = "Drivers Licence No.: "
        '
        'lblLPlateNo2FB
        '
        Me.lblLPlateNo2FB.AutoSize = True
        Me.lblLPlateNo2FB.Font = New System.Drawing.Font("Palatino Linotype", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblLPlateNo2FB.Location = New System.Drawing.Point(86, 173)
        Me.lblLPlateNo2FB.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblLPlateNo2FB.Name = "lblLPlateNo2FB"
        Me.lblLPlateNo2FB.Size = New System.Drawing.Size(134, 22)
        Me.lblLPlateNo2FB.TabIndex = 28
        Me.lblLPlateNo2FB.Text = "License Plate No.: "
        '
        'lblName2FB
        '
        Me.lblName2FB.AutoSize = True
        Me.lblName2FB.Font = New System.Drawing.Font("Palatino Linotype", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblName2FB.Location = New System.Drawing.Point(86, 109)
        Me.lblName2FB.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblName2FB.Name = "lblName2FB"
        Me.lblName2FB.Size = New System.Drawing.Size(94, 22)
        Me.lblName2FB.TabIndex = 26
        Me.lblName2FB.Text = "First Name: "
        '
        'lblTokenNoFB
        '
        Me.lblTokenNoFB.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblTokenNoFB.Location = New System.Drawing.Point(263, 69)
        Me.lblTokenNoFB.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblTokenNoFB.Name = "lblTokenNoFB"
        Me.lblTokenNoFB.Size = New System.Drawing.Size(83, 31)
        Me.lblTokenNoFB.TabIndex = 25
        Me.lblTokenNoFB.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'lblTokenFB
        '
        Me.lblTokenFB.AutoSize = True
        Me.lblTokenFB.Font = New System.Drawing.Font("Palatino Linotype", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblTokenFB.Location = New System.Drawing.Point(86, 77)
        Me.lblTokenFB.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblTokenFB.Name = "lblTokenFB"
        Me.lblTokenFB.Size = New System.Drawing.Size(173, 22)
        Me.lblTokenFB.TabIndex = 24
        Me.lblTokenFB.Text = "Your Token Number is: "
        '
        'lblTotalChargesFB
        '
        Me.lblTotalChargesFB.AutoSize = True
        Me.lblTotalChargesFB.Font = New System.Drawing.Font("Palatino Linotype", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblTotalChargesFB.Location = New System.Drawing.Point(86, 468)
        Me.lblTotalChargesFB.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblTotalChargesFB.Name = "lblTotalChargesFB"
        Me.lblTotalChargesFB.Size = New System.Drawing.Size(112, 22)
        Me.lblTotalChargesFB.TabIndex = 44
        Me.lblTotalChargesFB.Text = "Total Charges: "
        '
        'lblTotalChargesFB2
        '
        Me.lblTotalChargesFB2.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblTotalChargesFB2.Location = New System.Drawing.Point(243, 459)
        Me.lblTotalChargesFB2.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblTotalChargesFB2.Name = "lblTotalChargesFB2"
        Me.lblTotalChargesFB2.Size = New System.Drawing.Size(218, 31)
        Me.lblTotalChargesFB2.TabIndex = 45
        Me.lblTotalChargesFB2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'lblFinalBillHeader
        '
        Me.lblFinalBillHeader.AutoSize = True
        Me.lblFinalBillHeader.Font = New System.Drawing.Font("Palatino Linotype", 14.0!, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblFinalBillHeader.Location = New System.Drawing.Point(86, 41)
        Me.lblFinalBillHeader.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblFinalBillHeader.Name = "lblFinalBillHeader"
        Me.lblFinalBillHeader.Size = New System.Drawing.Size(182, 26)
        Me.lblFinalBillHeader.TabIndex = 46
        Me.lblFinalBillHeader.Text = "Final Bill of Service:-"
        '
        'lblFinalBillFooter
        '
        Me.lblFinalBillFooter.AutoSize = True
        Me.lblFinalBillFooter.Font = New System.Drawing.Font("Palatino Linotype", 14.0!, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblFinalBillFooter.Location = New System.Drawing.Point(591, 506)
        Me.lblFinalBillFooter.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblFinalBillFooter.Name = "lblFinalBillFooter"
        Me.lblFinalBillFooter.Size = New System.Drawing.Size(148, 26)
        Me.lblFinalBillFooter.TabIndex = 47
        Me.lblFinalBillFooter.Text = "THANK YOU!!!"
        '
        'lblServiceChargesFB2
        '
        Me.lblServiceChargesFB2.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblServiceChargesFB2.Location = New System.Drawing.Point(243, 393)
        Me.lblServiceChargesFB2.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblServiceChargesFB2.Name = "lblServiceChargesFB2"
        Me.lblServiceChargesFB2.Size = New System.Drawing.Size(218, 31)
        Me.lblServiceChargesFB2.TabIndex = 49
        Me.lblServiceChargesFB2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'lblServiceChargesFB
        '
        Me.lblServiceChargesFB.AutoSize = True
        Me.lblServiceChargesFB.Font = New System.Drawing.Font("Palatino Linotype", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblServiceChargesFB.Location = New System.Drawing.Point(86, 402)
        Me.lblServiceChargesFB.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblServiceChargesFB.Name = "lblServiceChargesFB"
        Me.lblServiceChargesFB.Size = New System.Drawing.Size(126, 22)
        Me.lblServiceChargesFB.TabIndex = 48
        Me.lblServiceChargesFB.Text = "Service Charges: "
        '
        'lblParkigChargesFB2
        '
        Me.lblParkigChargesFB2.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblParkigChargesFB2.Location = New System.Drawing.Point(243, 426)
        Me.lblParkigChargesFB2.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblParkigChargesFB2.Name = "lblParkigChargesFB2"
        Me.lblParkigChargesFB2.Size = New System.Drawing.Size(218, 31)
        Me.lblParkigChargesFB2.TabIndex = 51
        Me.lblParkigChargesFB2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'lblParkingChargesFB
        '
        Me.lblParkingChargesFB.AutoSize = True
        Me.lblParkingChargesFB.Font = New System.Drawing.Font("Palatino Linotype", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblParkingChargesFB.Location = New System.Drawing.Point(86, 435)
        Me.lblParkingChargesFB.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblParkingChargesFB.Name = "lblParkingChargesFB"
        Me.lblParkingChargesFB.Size = New System.Drawing.Size(132, 22)
        Me.lblParkingChargesFB.TabIndex = 50
        Me.lblParkingChargesFB.Text = "Parking Charges: "
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Palatino Linotype", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(86, 141)
        Me.Label1.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(93, 22)
        Me.Label1.TabIndex = 52
        Me.Label1.Text = "Last Name: "
        '
        'lblLName2rFB
        '
        Me.lblLName2rFB.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblLName2rFB.Location = New System.Drawing.Point(243, 132)
        Me.lblLName2rFB.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblLName2rFB.Name = "lblLName2rFB"
        Me.lblLName2rFB.Size = New System.Drawing.Size(185, 31)
        Me.lblLName2rFB.TabIndex = 53
        Me.lblLName2rFB.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'FinalBill
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(884, 554)
        Me.Controls.Add(Me.lblLName2rFB)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.lblParkigChargesFB2)
        Me.Controls.Add(Me.lblParkingChargesFB)
        Me.Controls.Add(Me.lblServiceChargesFB2)
        Me.Controls.Add(Me.lblServiceChargesFB)
        Me.Controls.Add(Me.lblFinalBillFooter)
        Me.Controls.Add(Me.lblFinalBillHeader)
        Me.Controls.Add(Me.lblTotalChargesFB2)
        Me.Controls.Add(Me.lblTotalChargesFB)
        Me.Controls.Add(Me.lblTotalTimeFB)
        Me.Controls.Add(Me.lblTotalTFB)
        Me.Controls.Add(Me.lblOutTime2rFB)
        Me.Controls.Add(Me.lblOutTimeFB)
        Me.Controls.Add(Me.lblServicesSelectedFB)
        Me.Controls.Add(Me.lblInTime2rFB)
        Me.Controls.Add(Me.lblInTimeFB)
        Me.Controls.Add(Me.lblService2FB)
        Me.Controls.Add(Me.lblContactNo2rFB)
        Me.Controls.Add(Me.lblDLNo2rFB)
        Me.Controls.Add(Me.lblLPlaneNo2rFB)
        Me.Controls.Add(Me.lblFName2rFB)
        Me.Controls.Add(Me.lblContactNo2FB)
        Me.Controls.Add(Me.lblDLNo2FB)
        Me.Controls.Add(Me.lblLPlateNo2FB)
        Me.Controls.Add(Me.lblName2FB)
        Me.Controls.Add(Me.lblTokenNoFB)
        Me.Controls.Add(Me.lblTokenFB)
        Me.Margin = New System.Windows.Forms.Padding(2)
        Me.Name = "FinalBill"
        Me.Text = "FinalBill"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents lblTotalTimeFB As Label
    Friend WithEvents lblTotalTFB As Label
    Friend WithEvents lblOutTime2rFB As Label
    Friend WithEvents lblOutTimeFB As Label
    Friend WithEvents lblServicesSelectedFB As Label
    Friend WithEvents lblInTime2rFB As Label
    Friend WithEvents lblInTimeFB As Label
    Friend WithEvents lblService2FB As Label
    Friend WithEvents lblContactNo2rFB As Label
    Friend WithEvents lblDLNo2rFB As Label
    Friend WithEvents lblLPlaneNo2rFB As Label
    Friend WithEvents lblFName2rFB As Label
    Friend WithEvents lblContactNo2FB As Label
    Friend WithEvents lblDLNo2FB As Label
    Friend WithEvents lblLPlateNo2FB As Label
    Friend WithEvents lblName2FB As Label
    Friend WithEvents lblTokenNoFB As Label
    Friend WithEvents lblTokenFB As Label
    Friend WithEvents lblTotalChargesFB As Label
    Friend WithEvents lblTotalChargesFB2 As Label
    Friend WithEvents lblFinalBillHeader As Label
    Friend WithEvents lblFinalBillFooter As Label
    Friend WithEvents lblServiceChargesFB2 As Label
    Friend WithEvents lblServiceChargesFB As Label
    Friend WithEvents lblParkigChargesFB2 As Label
    Friend WithEvents lblParkingChargesFB As Label
    Friend WithEvents Label1 As Label
    Friend WithEvents lblLName2rFB As Label
End Class
