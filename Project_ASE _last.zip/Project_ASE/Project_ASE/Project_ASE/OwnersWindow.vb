﻿Imports System.Data.SqlClient

Public Class OwnersWindow
    Private DBCon As SqlConnection = New SqlConnection("Server=DESKTOP-CVQ6DL9;Database=ParkingService;Trusted_Connection=True;")
    Private DBCmd As SqlCommand = New SqlCommand
    Private Sub btnPrint_Click(sender As Object, e As EventArgs)
        PrintPreviewDialog1.Document = PrintDocument1
        PrintPreviewDialog1.ShowDialog()
    End Sub
    Private Function TicketGet(TicketHeaderID As Int32)
        Dim LocalDA As SqlDataAdapter = New SqlDataAdapter(DBCmd)
        Dim LocalDS As DataSet = New DataSet

        DBCmd.CommandType = CommandType.StoredProcedure
        DBCmd.CommandText = "sp_TicketHeaderGet"
        DBCmd.Parameters.Clear()
        DBCmd.Parameters.AddWithValue("TicketHeaderID", TicketHeaderID)
        LocalDA.Fill(LocalDS)
        TicketGet = LocalDS


    End Function
    Private Sub OwnersWindow_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'TODO: This line of code loads data into the 'ParkingServiceDataSet1.tbl_TicketHeader' table. You can move, or remove it, as needed.
        Me.Tbl_TicketHeaderTableAdapter1.Fill(Me.ParkingServiceDataSet1.tbl_TicketHeader)
        'TODO: This line of code loads data into the 'ParkingServiceDataSet.tbl_TicketHeader' table. You can move, or remove it, as needed.
        ' Me.Tbl_TicketHeaderTableAdapter.Fill(Me.ParkingServiceDataSet.tbl_TicketHeader)
        DBCmd.Connection = DBCon



        'Data Base should update the table on owners window when its getting loaded
    End Sub

    Private Sub btnReceipt_Click(sender As Object, e As EventArgs) Handles btnReceipt.Click
        Dim TicketHeaderID As Integer
        Dim TicketSet As DataSet = New DataSet

        If DataGridView1.SelectedRows.Count > 0 Then


            TicketHeaderID = DataGridView1.Rows(DataGridView1.SelectedRows(0).Index).Cells(0).Value
            TicketSet = TicketGet(TicketHeaderID)
            Dim tmpForm As Receipt = New Receipt(TicketSet)
            tmpForm.Show()

        End If
    End Sub

    Private Sub btnCheckOut_Click(sender As Object, e As EventArgs) Handles btnCheckOut.Click
        '  Dim TicketHeaderID As Integer
        '  Dim TicketSet As DataSet = New DataSet

        '  If DataGridView1.SelectedRows.Count > 0 Then


        'TicketHeaderID = DataGridView1.Rows(DataGridView1.SelectedRows(0).Index).Cells(0).Value
        'TicketSet = TicketGet(TicketHeaderID)
        'Dim tmpForm As FinalBill = New FinalBill(TicketSet)
        'tmpForm.Show()

        'End If
        FinalBill.Show()
        FinalBill.lblTokenNoFB.Text = Counter.ToString()
        FinalBill.lblFName2rFB.Text = Register.txtFName.Text
        FinalBill.lblLName2rFB.Text = Register.txtLName.Text
        FinalBill.lblLPlaneNo2rFB.Text = Register.txtLPlateNo.Text
        FinalBill.lblDLNo2rFB.Text = Register.txtDLNo.Text
        FinalBill.lblContactNo2rFB.Text = Register.txtContactNo.Text
        FinalBill.lblServicesSelectedFB.Text = str

        FinalBill.lblInTime2rFB.Text = InTime
        OutTime = TimeOfDay
        FinalBill.lblOutTime2rFB.Text = OutTime
        TotalTime = OutTime - InTime

        TotalHours = Convert.ToDouble(TotalTime.Minutes)
        ParkingCharges = TotalHours * ParkingPerHour

        FinalBill.lblServiceChargesFB2.Text = ServiceCharges
        FinalBill.lblParkigChargesFB2.Text = ParkingCharges

        TotalCharges = ParkingCharges + ServiceCharges

        FinalBill.lblTotalTimeFB.Text = TotalHours.ToString()

        FinalBill.lblTotalChargesFB2.Text = TotalCharges
    End Sub

    Private Sub DataGridView1_SelectionChanged(sender As Object, e As EventArgs) Handles DataGridView1.SelectionChanged

    End Sub

    Private Sub DataGridView1_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles DataGridView1.CellContentClick

    End Sub

    Private Sub TblTicketHeaderBindingSource1_CurrentChanged(sender As Object, e As EventArgs)

    End Sub

    Private Sub TblTicketHeaderBindingSource_CurrentChanged(sender As Object, e As EventArgs) Handles TblTicketHeaderBindingSource.CurrentChanged

    End Sub
End Class