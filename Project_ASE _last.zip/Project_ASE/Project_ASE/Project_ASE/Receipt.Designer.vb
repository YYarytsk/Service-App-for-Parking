﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Receipt
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.lblToken = New System.Windows.Forms.Label()
        Me.lblTokenNo = New System.Windows.Forms.Label()
        Me.lblContactNo2 = New System.Windows.Forms.Label()
        Me.lblDLNo2 = New System.Windows.Forms.Label()
        Me.lblLPlateNo2 = New System.Windows.Forms.Label()
        Me.lblLName2 = New System.Windows.Forms.Label()
        Me.lblFname2 = New System.Windows.Forms.Label()
        Me.lblFName2r = New System.Windows.Forms.Label()
        Me.lblLName2r = New System.Windows.Forms.Label()
        Me.lblLPlaneNo2r = New System.Windows.Forms.Label()
        Me.lblDLNo2r = New System.Windows.Forms.Label()
        Me.lblContactNo2r = New System.Windows.Forms.Label()
        Me.lblService2 = New System.Windows.Forms.Label()
        Me.lblInTime = New System.Windows.Forms.Label()
        Me.lblInTime2r = New System.Windows.Forms.Label()
        Me.lblServicesSelected = New System.Windows.Forms.Label()
        Me.lblReceiptHeader = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'lblToken
        '
        Me.lblToken.AutoSize = True
        Me.lblToken.Font = New System.Drawing.Font("Palatino Linotype", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblToken.Location = New System.Drawing.Point(100, 98)
        Me.lblToken.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblToken.Name = "lblToken"
        Me.lblToken.Size = New System.Drawing.Size(173, 22)
        Me.lblToken.TabIndex = 2
        Me.lblToken.Text = "Your Token Number is: "
        '
        'lblTokenNo
        '
        Me.lblTokenNo.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblTokenNo.Location = New System.Drawing.Point(286, 94)
        Me.lblTokenNo.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblTokenNo.Name = "lblTokenNo"
        Me.lblTokenNo.Size = New System.Drawing.Size(75, 31)
        Me.lblTokenNo.TabIndex = 3
        Me.lblTokenNo.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'lblContactNo2
        '
        Me.lblContactNo2.AutoSize = True
        Me.lblContactNo2.Font = New System.Drawing.Font("Palatino Linotype", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblContactNo2.Location = New System.Drawing.Point(100, 278)
        Me.lblContactNo2.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblContactNo2.Name = "lblContactNo2"
        Me.lblContactNo2.Size = New System.Drawing.Size(96, 22)
        Me.lblContactNo2.TabIndex = 10
        Me.lblContactNo2.Text = "Contact No.:"
        '
        'lblDLNo2
        '
        Me.lblDLNo2.AutoSize = True
        Me.lblDLNo2.Font = New System.Drawing.Font("Palatino Linotype", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblDLNo2.Location = New System.Drawing.Point(100, 242)
        Me.lblDLNo2.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblDLNo2.Name = "lblDLNo2"
        Me.lblDLNo2.Size = New System.Drawing.Size(151, 22)
        Me.lblDLNo2.TabIndex = 9
        Me.lblDLNo2.Text = "Drivers Licence No.: "
        '
        'lblLPlateNo2
        '
        Me.lblLPlateNo2.AutoSize = True
        Me.lblLPlateNo2.Font = New System.Drawing.Font("Palatino Linotype", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblLPlateNo2.Location = New System.Drawing.Point(100, 206)
        Me.lblLPlateNo2.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblLPlateNo2.Name = "lblLPlateNo2"
        Me.lblLPlateNo2.Size = New System.Drawing.Size(134, 22)
        Me.lblLPlateNo2.TabIndex = 8
        Me.lblLPlateNo2.Text = "License Plate No.: "
        '
        'lblLName2
        '
        Me.lblLName2.AutoSize = True
        Me.lblLName2.Font = New System.Drawing.Font("Palatino Linotype", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblLName2.Location = New System.Drawing.Point(100, 170)
        Me.lblLName2.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblLName2.Name = "lblLName2"
        Me.lblLName2.Size = New System.Drawing.Size(93, 22)
        Me.lblLName2.TabIndex = 7
        Me.lblLName2.Text = "Last Name: "
        '
        'lblFname2
        '
        Me.lblFname2.AutoSize = True
        Me.lblFname2.Font = New System.Drawing.Font("Palatino Linotype", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblFname2.Location = New System.Drawing.Point(100, 134)
        Me.lblFname2.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblFname2.Name = "lblFname2"
        Me.lblFname2.Size = New System.Drawing.Size(94, 22)
        Me.lblFname2.TabIndex = 6
        Me.lblFname2.Text = "First Name: "
        '
        'lblFName2r
        '
        Me.lblFName2r.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblFName2r.Location = New System.Drawing.Point(287, 136)
        Me.lblFName2r.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblFName2r.Name = "lblFName2r"
        Me.lblFName2r.Size = New System.Drawing.Size(210, 31)
        Me.lblFName2r.TabIndex = 11
        Me.lblFName2r.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'lblLName2r
        '
        Me.lblLName2r.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblLName2r.Location = New System.Drawing.Point(287, 173)
        Me.lblLName2r.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblLName2r.Name = "lblLName2r"
        Me.lblLName2r.Size = New System.Drawing.Size(210, 31)
        Me.lblLName2r.TabIndex = 12
        Me.lblLName2r.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'lblLPlaneNo2r
        '
        Me.lblLPlaneNo2r.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblLPlaneNo2r.Location = New System.Drawing.Point(287, 210)
        Me.lblLPlaneNo2r.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblLPlaneNo2r.Name = "lblLPlaneNo2r"
        Me.lblLPlaneNo2r.Size = New System.Drawing.Size(210, 31)
        Me.lblLPlaneNo2r.TabIndex = 13
        Me.lblLPlaneNo2r.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'lblDLNo2r
        '
        Me.lblDLNo2r.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblDLNo2r.Location = New System.Drawing.Point(287, 245)
        Me.lblDLNo2r.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblDLNo2r.Name = "lblDLNo2r"
        Me.lblDLNo2r.Size = New System.Drawing.Size(210, 31)
        Me.lblDLNo2r.TabIndex = 14
        Me.lblDLNo2r.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'lblContactNo2r
        '
        Me.lblContactNo2r.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblContactNo2r.Location = New System.Drawing.Point(287, 279)
        Me.lblContactNo2r.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblContactNo2r.Name = "lblContactNo2r"
        Me.lblContactNo2r.Size = New System.Drawing.Size(210, 31)
        Me.lblContactNo2r.TabIndex = 15
        Me.lblContactNo2r.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'lblService2
        '
        Me.lblService2.AutoSize = True
        Me.lblService2.Font = New System.Drawing.Font("Palatino Linotype", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblService2.Location = New System.Drawing.Point(100, 314)
        Me.lblService2.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblService2.Name = "lblService2"
        Me.lblService2.Size = New System.Drawing.Size(125, 22)
        Me.lblService2.TabIndex = 16
        Me.lblService2.Text = "Selected Service.:"
        '
        'lblInTime
        '
        Me.lblInTime.AutoSize = True
        Me.lblInTime.Font = New System.Drawing.Font("Palatino Linotype", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblInTime.Location = New System.Drawing.Point(100, 350)
        Me.lblInTime.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblInTime.Name = "lblInTime"
        Me.lblInTime.Size = New System.Drawing.Size(70, 22)
        Me.lblInTime.TabIndex = 17
        Me.lblInTime.Text = "In Time: "
        '
        'lblInTime2r
        '
        Me.lblInTime2r.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblInTime2r.Location = New System.Drawing.Point(287, 352)
        Me.lblInTime2r.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblInTime2r.Name = "lblInTime2r"
        Me.lblInTime2r.Size = New System.Drawing.Size(210, 31)
        Me.lblInTime2r.TabIndex = 18
        Me.lblInTime2r.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'lblServicesSelected
        '
        Me.lblServicesSelected.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblServicesSelected.Location = New System.Drawing.Point(288, 313)
        Me.lblServicesSelected.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblServicesSelected.Name = "lblServicesSelected"
        Me.lblServicesSelected.Size = New System.Drawing.Size(404, 34)
        Me.lblServicesSelected.TabIndex = 19
        Me.lblServicesSelected.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'lblReceiptHeader
        '
        Me.lblReceiptHeader.AutoSize = True
        Me.lblReceiptHeader.Font = New System.Drawing.Font("Palatino Linotype", 14.0!, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblReceiptHeader.Location = New System.Drawing.Point(102, 46)
        Me.lblReceiptHeader.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblReceiptHeader.Name = "lblReceiptHeader"
        Me.lblReceiptHeader.Size = New System.Drawing.Size(169, 26)
        Me.lblReceiptHeader.TabIndex = 20
        Me.lblReceiptHeader.Text = "Receipt of Service:-"
        '
        'Receipt
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(712, 514)
        Me.Controls.Add(Me.lblReceiptHeader)
        Me.Controls.Add(Me.lblServicesSelected)
        Me.Controls.Add(Me.lblInTime2r)
        Me.Controls.Add(Me.lblInTime)
        Me.Controls.Add(Me.lblService2)
        Me.Controls.Add(Me.lblContactNo2r)
        Me.Controls.Add(Me.lblDLNo2r)
        Me.Controls.Add(Me.lblLPlaneNo2r)
        Me.Controls.Add(Me.lblLName2r)
        Me.Controls.Add(Me.lblFName2r)
        Me.Controls.Add(Me.lblContactNo2)
        Me.Controls.Add(Me.lblDLNo2)
        Me.Controls.Add(Me.lblLPlateNo2)
        Me.Controls.Add(Me.lblLName2)
        Me.Controls.Add(Me.lblFname2)
        Me.Controls.Add(Me.lblTokenNo)
        Me.Controls.Add(Me.lblToken)
        Me.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.Name = "Receipt"
        Me.Text = "Receipt"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents lblToken As Label
    Friend WithEvents lblTokenNo As Label
    Friend WithEvents lblContactNo2 As Label
    Friend WithEvents lblDLNo2 As Label
    Friend WithEvents lblLPlateNo2 As Label
    Friend WithEvents lblLName2 As Label
    Friend WithEvents lblFname2 As Label
    Friend WithEvents lblFName2r As Label
    Friend WithEvents lblLName2r As Label
    Friend WithEvents lblLPlaneNo2r As Label
    Friend WithEvents lblDLNo2r As Label
    Friend WithEvents lblContactNo2r As Label
    Friend WithEvents lblService2 As Label
    Friend WithEvents lblInTime As Label
    Friend WithEvents lblInTime2r As Label
    Friend WithEvents lblServicesSelected As Label
    Friend WithEvents lblReceiptHeader As Label
End Class
