﻿Partial Class ParkingServiceDataSet
    Partial Public Class tbl_TicketHeaderDataTable
        Private Sub tbl_TicketHeaderDataTable_ColumnChanging(sender As Object, e As DataColumnChangeEventArgs) Handles Me.ColumnChanging
            If (e.Column.ColumnName = Me.TicketHeaderTimeInColumn.ColumnName) Then
                'Add user code here
            End If

        End Sub

    End Class
End Class

Namespace ParkingServiceDataSetTableAdapters

    Partial Public Class tbl_TicketHeaderTableAdapter
    End Class
End Namespace
