﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class OwnersWindow
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(OwnersWindow))
        Me.PrintPreviewDialog1 = New System.Windows.Forms.PrintPreviewDialog()
        Me.PrintDocument1 = New System.Drawing.Printing.PrintDocument()
        Me.btnReceipt = New System.Windows.Forms.Button()
        Me.btnCheckOut = New System.Windows.Forms.Button()
        Me.DataGridView1 = New System.Windows.Forms.DataGridView()
        Me.ParkingServiceDataSetBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.ParkingServiceDataSet = New Project_ASE.ParkingServiceDataSet()
        Me.TblTicketHeaderBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.Tbl_TicketHeaderTableAdapter = New Project_ASE.ParkingServiceDataSetTableAdapters.tbl_TicketHeaderTableAdapter()
        Me.TicketHeaderIDDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.TicketHeaderCustFNameDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.TicketHeaderCustLNameDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.TicketHeaderCustCarPlateNumberDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.TicketHeaderCustDLNumberDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.TicketHeaderCustPhoneNumberDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.TicketHeaderServicesSelectedDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.TicketHeaderTimeInDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.ParkingServiceDataSet1 = New Project_ASE.ParkingServiceDataSet1()
        Me.TblTicketHeaderBindingSource1 = New System.Windows.Forms.BindingSource(Me.components)
        Me.Tbl_TicketHeaderTableAdapter1 = New Project_ASE.ParkingServiceDataSet1TableAdapters.tbl_TicketHeaderTableAdapter()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.ParkingServiceDataSetBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.ParkingServiceDataSet, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TblTicketHeaderBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.ParkingServiceDataSet1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TblTicketHeaderBindingSource1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'PrintPreviewDialog1
        '
        Me.PrintPreviewDialog1.AutoScrollMargin = New System.Drawing.Size(0, 0)
        Me.PrintPreviewDialog1.AutoScrollMinSize = New System.Drawing.Size(0, 0)
        Me.PrintPreviewDialog1.ClientSize = New System.Drawing.Size(400, 300)
        Me.PrintPreviewDialog1.Enabled = True
        Me.PrintPreviewDialog1.Icon = CType(resources.GetObject("PrintPreviewDialog1.Icon"), System.Drawing.Icon)
        Me.PrintPreviewDialog1.Name = "PrintPreviewDialog1"
        Me.PrintPreviewDialog1.Visible = False
        '
        'btnReceipt
        '
        Me.btnReceipt.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnReceipt.Location = New System.Drawing.Point(92, 312)
        Me.btnReceipt.Margin = New System.Windows.Forms.Padding(2)
        Me.btnReceipt.Name = "btnReceipt"
        Me.btnReceipt.Size = New System.Drawing.Size(69, 28)
        Me.btnReceipt.TabIndex = 24
        Me.btnReceipt.Text = "Receipt"
        Me.btnReceipt.UseVisualStyleBackColor = True
        '
        'btnCheckOut
        '
        Me.btnCheckOut.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnCheckOut.Location = New System.Drawing.Point(432, 312)
        Me.btnCheckOut.Margin = New System.Windows.Forms.Padding(2)
        Me.btnCheckOut.Name = "btnCheckOut"
        Me.btnCheckOut.Size = New System.Drawing.Size(88, 28)
        Me.btnCheckOut.TabIndex = 25
        Me.btnCheckOut.Text = "Check Out"
        Me.btnCheckOut.UseVisualStyleBackColor = True
        '
        'DataGridView1
        '
        Me.DataGridView1.AllowUserToOrderColumns = True
        Me.DataGridView1.AutoGenerateColumns = False
        Me.DataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridView1.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.TicketHeaderIDDataGridViewTextBoxColumn, Me.TicketHeaderCustFNameDataGridViewTextBoxColumn, Me.TicketHeaderCustLNameDataGridViewTextBoxColumn, Me.TicketHeaderCustCarPlateNumberDataGridViewTextBoxColumn, Me.TicketHeaderCustDLNumberDataGridViewTextBoxColumn, Me.TicketHeaderCustPhoneNumberDataGridViewTextBoxColumn, Me.TicketHeaderServicesSelectedDataGridViewTextBoxColumn, Me.TicketHeaderTimeInDataGridViewTextBoxColumn})
        Me.DataGridView1.DataSource = Me.TblTicketHeaderBindingSource1
        Me.DataGridView1.Location = New System.Drawing.Point(12, 12)
        Me.DataGridView1.Name = "DataGridView1"
        Me.DataGridView1.RowHeadersVisible = False
        Me.DataGridView1.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.DataGridView1.Size = New System.Drawing.Size(879, 253)
        Me.DataGridView1.TabIndex = 26
        '
        'ParkingServiceDataSetBindingSource
        '
        Me.ParkingServiceDataSetBindingSource.DataSource = Me.ParkingServiceDataSet
        Me.ParkingServiceDataSetBindingSource.Position = 0
        '
        'ParkingServiceDataSet
        '
        Me.ParkingServiceDataSet.DataSetName = "ParkingServiceDataSet"
        Me.ParkingServiceDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'TblTicketHeaderBindingSource
        '
        Me.TblTicketHeaderBindingSource.DataMember = "tbl_TicketHeader"
        Me.TblTicketHeaderBindingSource.DataSource = Me.ParkingServiceDataSet
        '
        'Tbl_TicketHeaderTableAdapter
        '
        Me.Tbl_TicketHeaderTableAdapter.ClearBeforeFill = True
        '
        'TicketHeaderIDDataGridViewTextBoxColumn
        '
        Me.TicketHeaderIDDataGridViewTextBoxColumn.DataPropertyName = "TicketHeaderID"
        Me.TicketHeaderIDDataGridViewTextBoxColumn.HeaderText = "TicketHeaderID"
        Me.TicketHeaderIDDataGridViewTextBoxColumn.Name = "TicketHeaderIDDataGridViewTextBoxColumn"
        '
        'TicketHeaderCustFNameDataGridViewTextBoxColumn
        '
        Me.TicketHeaderCustFNameDataGridViewTextBoxColumn.DataPropertyName = "TicketHeaderCustFName"
        Me.TicketHeaderCustFNameDataGridViewTextBoxColumn.HeaderText = "TicketHeaderCustFName"
        Me.TicketHeaderCustFNameDataGridViewTextBoxColumn.Name = "TicketHeaderCustFNameDataGridViewTextBoxColumn"
        '
        'TicketHeaderCustLNameDataGridViewTextBoxColumn
        '
        Me.TicketHeaderCustLNameDataGridViewTextBoxColumn.DataPropertyName = "TicketHeaderCustLName"
        Me.TicketHeaderCustLNameDataGridViewTextBoxColumn.HeaderText = "TicketHeaderCustLName"
        Me.TicketHeaderCustLNameDataGridViewTextBoxColumn.Name = "TicketHeaderCustLNameDataGridViewTextBoxColumn"
        '
        'TicketHeaderCustCarPlateNumberDataGridViewTextBoxColumn
        '
        Me.TicketHeaderCustCarPlateNumberDataGridViewTextBoxColumn.DataPropertyName = "TicketHeaderCustCarPlateNumber"
        Me.TicketHeaderCustCarPlateNumberDataGridViewTextBoxColumn.HeaderText = "TicketHeaderCustCarPlateNumber"
        Me.TicketHeaderCustCarPlateNumberDataGridViewTextBoxColumn.Name = "TicketHeaderCustCarPlateNumberDataGridViewTextBoxColumn"
        '
        'TicketHeaderCustDLNumberDataGridViewTextBoxColumn
        '
        Me.TicketHeaderCustDLNumberDataGridViewTextBoxColumn.DataPropertyName = "TicketHeaderCustDLNumber"
        Me.TicketHeaderCustDLNumberDataGridViewTextBoxColumn.HeaderText = "TicketHeaderCustDLNumber"
        Me.TicketHeaderCustDLNumberDataGridViewTextBoxColumn.Name = "TicketHeaderCustDLNumberDataGridViewTextBoxColumn"
        '
        'TicketHeaderCustPhoneNumberDataGridViewTextBoxColumn
        '
        Me.TicketHeaderCustPhoneNumberDataGridViewTextBoxColumn.DataPropertyName = "TicketHeaderCustPhoneNumber"
        Me.TicketHeaderCustPhoneNumberDataGridViewTextBoxColumn.HeaderText = "TicketHeaderCustPhoneNumber"
        Me.TicketHeaderCustPhoneNumberDataGridViewTextBoxColumn.Name = "TicketHeaderCustPhoneNumberDataGridViewTextBoxColumn"
        '
        'TicketHeaderServicesSelectedDataGridViewTextBoxColumn
        '
        Me.TicketHeaderServicesSelectedDataGridViewTextBoxColumn.DataPropertyName = "TicketHeaderServicesSelected"
        Me.TicketHeaderServicesSelectedDataGridViewTextBoxColumn.HeaderText = "TicketHeaderServicesSelected"
        Me.TicketHeaderServicesSelectedDataGridViewTextBoxColumn.Name = "TicketHeaderServicesSelectedDataGridViewTextBoxColumn"
        '
        'TicketHeaderTimeInDataGridViewTextBoxColumn
        '
        Me.TicketHeaderTimeInDataGridViewTextBoxColumn.DataPropertyName = "TicketHeaderTimeIn"
        Me.TicketHeaderTimeInDataGridViewTextBoxColumn.HeaderText = "TicketHeaderTimeIn"
        Me.TicketHeaderTimeInDataGridViewTextBoxColumn.Name = "TicketHeaderTimeInDataGridViewTextBoxColumn"
        Me.TicketHeaderTimeInDataGridViewTextBoxColumn.ReadOnly = True
        '
        'ParkingServiceDataSet1
        '
        Me.ParkingServiceDataSet1.DataSetName = "ParkingServiceDataSet1"
        Me.ParkingServiceDataSet1.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'TblTicketHeaderBindingSource1
        '
        Me.TblTicketHeaderBindingSource1.DataMember = "tbl_TicketHeader"
        Me.TblTicketHeaderBindingSource1.DataSource = Me.ParkingServiceDataSet1
        '
        'Tbl_TicketHeaderTableAdapter1
        '
        Me.Tbl_TicketHeaderTableAdapter1.ClearBeforeFill = True
        '
        'OwnersWindow
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(903, 366)
        Me.Controls.Add(Me.DataGridView1)
        Me.Controls.Add(Me.btnCheckOut)
        Me.Controls.Add(Me.btnReceipt)
        Me.Margin = New System.Windows.Forms.Padding(2)
        Me.Name = "OwnersWindow"
        Me.Text = "OwnersWindow"
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.ParkingServiceDataSetBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.ParkingServiceDataSet, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TblTicketHeaderBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.ParkingServiceDataSet1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TblTicketHeaderBindingSource1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents PrintPreviewDialog1 As PrintPreviewDialog
    Friend WithEvents PrintDocument1 As Printing.PrintDocument
    Friend WithEvents btnReceipt As Button
    Friend WithEvents btnCheckOut As Button
    Friend WithEvents DataGridView1 As DataGridView
    Friend WithEvents ParkingServiceDataSet As ParkingServiceDataSet
    Friend WithEvents TblTicketHeaderBindingSource As BindingSource
    Friend WithEvents Tbl_TicketHeaderTableAdapter As ParkingServiceDataSetTableAdapters.tbl_TicketHeaderTableAdapter
    Friend WithEvents ParkingServiceDataSetBindingSource As BindingSource
    Friend WithEvents TicketHeaderIDDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents TicketHeaderCustFNameDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents TicketHeaderCustLNameDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents TicketHeaderCustCarPlateNumberDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents TicketHeaderCustDLNumberDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents TicketHeaderCustPhoneNumberDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents TicketHeaderServicesSelectedDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents TicketHeaderTimeInDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents ParkingServiceDataSet1 As ParkingServiceDataSet1
    Friend WithEvents TblTicketHeaderBindingSource1 As BindingSource
    Friend WithEvents Tbl_TicketHeaderTableAdapter1 As ParkingServiceDataSet1TableAdapters.tbl_TicketHeaderTableAdapter
End Class
