﻿Public Class Receipt
    Dim i As Integer
    Dim j As Integer

    Private TicketSet As DataSet
    Public Sub New(_TicketSet As DataSet)

        InitializeComponent()
        TicketSet = _TicketSet
        ' Add any initialization after the InitializeComponent() call.

    End Sub

    Public Property Table1 As Object

    Private Sub Receipt_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        lblTokenNo.Text = TicketSet.Tables(0).Rows(0)("TicketHeaderID")
        lblFName2r.Text = TicketSet.Tables(0).Rows(0)("TicketHeaderCustFName")
        lblLName2r.Text = TicketSet.Tables(0).Rows(0)("TicketHeaderCustLName")
        lblLPlaneNo2r.Text = TicketSet.Tables(0).Rows(0)("TicketHeaderCustCarPlateNumber")
        lblDLNo2r.Text = TicketSet.Tables(0).Rows(0)("TicketHeaderCustDLNumber")
        lblContactNo2r.Text = TicketSet.Tables(0).Rows(0)("TicketHeaderCustPhoneNumber")
        lblServicesSelected.Text = TicketSet.Tables(0).Rows(0)("TicketHeaderServicesSelected")
        lblInTime2r.Text = TicketSet.Tables(0).Rows(0)("TicketHeaderTimeIn")


        ' For i = 1 To Table1.Rows.Count
        'For Case TickeDetailServiceID = 1 then
        ' Next
        ' For j = 0 To Table1.Rows(i).Cells.Count

        ' Change the inner HTML of the cell.
        'Table1.Rows(i).Cells(j).InnerHtml = "Row " & i.ToString() &
        '                              ", Column " & j.ToString()
        'Next j

        'Next i

    End Sub


End Class